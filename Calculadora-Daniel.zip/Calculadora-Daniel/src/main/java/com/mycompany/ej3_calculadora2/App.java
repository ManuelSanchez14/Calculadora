package com.mycompany.ej3_calculadora2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * Author Daniel
 * 
 * Mejoras
 * - Ahora se pueden realizar operaciones de manera consecutiva
 * - Visibilidad de todas las operaciones en la pantalla (Todavia NO)
 * - Nuevas operaciones: % , √ y ^
 * - Historial
 * - Botón para cambiar el signo del numero (+/-)
 */

public class App extends Application 
{

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException 
    {
        scene = new Scene(loadFXML("Calculadora"));
        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException 
    {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException 
    {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) 
    {
        launch();
    }

}