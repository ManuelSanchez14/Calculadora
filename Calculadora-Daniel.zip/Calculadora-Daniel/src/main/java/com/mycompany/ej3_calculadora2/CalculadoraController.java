package com.mycompany.ej3_calculadora2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class CalculadoraController implements Initializable {

    @FXML
    private Button b7, b6, b9, b5, b8, b4, b3, b2, b1, borrar, punto, b0, resta, suma, prod, div, calcular, cambiarSigno, raiz, porcentaje, potencia, toggleHistorial;
    @FXML
    private TextField pantalla;
    @FXML
    private ListView<String> historial;
    @FXML
    private Pane rootPane; // Asocia el contenedor principal desde el archivo FXML.
    @FXML
    private void borrarHistorial() {
        operaciones.clear(); // Limpia todas las operaciones del historial
}

    private String d1 = ""; // Primer operando
    private String d2 = ""; // Segundo operando
    private String res = ""; // Resultado
    private String op = ""; // Operador actual
    private boolean calc = false; // Indicador de cálculo realizado

    private final String errorInfinito = "Error: División por 0";
    private final String indeterminacion = "Indeterminación";
    private ObservableList<String> operaciones = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        historial.setItems(operaciones);
    }

    @FXML
    public void borrar() {
        pantalla.setText("");
        d1 = "";
        d2 = "";
        res = "";
        op = "";
        calc = false;
        pantalla.setStyle("-fx-text-fill: black");
    }

    @FXML
    private void setOp(ActionEvent event) {
        if (pantalla.getText().equals(errorInfinito)) {
            borrar();
            return;
        }

        Button botonPresionado = (Button) event.getSource();
        String nuevoOp = botonPresionado.getText();

        if (nuevoOp.equals("√")) {
            // Operación unaria (raíz cuadrada)
            if (!d1.isEmpty()) {
                double num1 = Double.parseDouble(d1);
                if (num1 < 0) {
                    pantalla.setText("Error: Raíz Negativa");
                    pantalla.setStyle("-fx-text-fill: red");
                } else {
                    res = String.valueOf(Math.sqrt(num1));
                    pantalla.setText(res);
                }
                calc = true;
                d1 = res; // Guarda el resultado en d1
                d2 = "";
                op = "";
            }
        } else {
            if (!op.isEmpty() && !d2.isEmpty()) {
                // Realiza el cálculo con los operandos actuales antes de establecer el nuevo operador
                realizarCalculo();
                d1 = res; // Usa el resultado como nuevo d1
                d2 = "";
            } else if (calc) {
                // Si ya se calculó, establece el resultado como nuevo d1
                d1 = res;
                calc = false;
            }

            op = nuevoOp;
            pantalla.setText(d1 + " " + op + " ");
        }
    }

    @FXML
    private void addN(ActionEvent event) {
        if (pantalla.getText().equals(errorInfinito)) {
            borrar();
            return;
        }

        Button botonPresionado = (Button) event.getSource();
        String textoBoton = botonPresionado.getText();

        if (op.isEmpty()) {
            // Si no hay operador, se está ingresando d1
            d1 += textoBoton;
            pantalla.setText(d1);
        } else {
            // Si hay operador, se está ingresando d2
            d2 += textoBoton;
            pantalla.setText(d1 + " " + op + " " + d2);
        }
    }

    @FXML
    private void calcular(ActionEvent event) {
        if (pantalla.getText().equals(errorInfinito)) {
            borrar();
            return;
        }

        realizarCalculo();
        if (!res.equals(errorInfinito) && !res.equals(indeterminacion)) {
            operaciones.add(d1 + " " + op + " " + d2 + " = " + res);
        }
        pantalla.setText(res);
        calc = true; // Indica que se ha completado un cálculo
    }

    private void realizarCalculo() {
        if (d1.isEmpty() || (d2.isEmpty() && !op.equals("%"))) {
            return; // No hay suficiente información para calcular
        }

        double num1 = Double.parseDouble(d1);
        double num2 = d2.isEmpty() ? 0 : Double.parseDouble(d2); // Para manejar %

        pantalla.setStyle("-fx-text-fill: black");

        switch (op) {
            case "+":
                res = String.valueOf(num1 + num2);
                break;
            case "-":
                res = String.valueOf(num1 - num2);
                break;
            case "*":
                res = String.valueOf(num1 * num2);
                break;
            case "/":
                if (num2 == 0) {
                    res = errorInfinito;
                    pantalla.setStyle("-fx-text-fill: red");
                } else {
                    res = String.valueOf(num1 / num2);
                }
                break;
            case "%":
                res = String.valueOf(num1 * num2 / 100);
                break;
            case "^":
                res = String.valueOf(Math.pow(num1, num2));
                break;
        }

        // Resetea los valores para permitir operaciones consecutivas
        d1 = res;
        d2 = "";
        op = "";
    }

    @FXML
    private void cambiarSigno() {
        if (!d2.isEmpty()) {
            d2 = String.valueOf(Double.parseDouble(d2) * -1);
            pantalla.setText(d1 + " " + op + " " + d2);
        } else if (!d1.isEmpty()) {
            d1 = String.valueOf(Double.parseDouble(d1) * -1);
            pantalla.setText(d1);
        }
    }

}
